import React, { useState } from 'react';
import SplashPage from './components/SplashPage';
import ProjectsPage from './components/ProjectsPage';
import AboutPage from './components/AboutPage';

function App() {
  const [currentPage, setCurrentPage] = useState('splash');

  return (
    <div>
      {currentPage === 'splash' && <SplashPage setCurrentPage={setCurrentPage} />}
      {currentPage === 'projects' && <ProjectsPage setCurrentPage={setCurrentPage} />}
      {currentPage === 'about' && <AboutPage setCurrentPage={setCurrentPage} />}
    </div>
  );
}

export default App;