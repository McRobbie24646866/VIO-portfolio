import React, { useState } from 'react';
import { Code, Github, ExternalLink, X } from 'lucide-react';
import './ProjectsPage.css';

const ProjectsPage = ({ setCurrentPage }) => {
  const [selectedProject, setSelectedProject] = useState(null);
  
  const projects = [
    {
      title: "Website react project (IMY220 Project)",
      distance: "Marathon Project",
      description: "Version control application",
      tech: ["React", "Node.js", "MongoDB", "tailwind"],
      github: "#",
      demo: "#"
    },
    {
      title: "LAMB STACK website (COS216 Project)",
      distance: "10K Sprint",
      description: "fully functional LAMB stack e-commerce website that stores data in a database",
      tech: ["typescript", "API Integration", "LAMB"],
      github: "#",
      demo: "#"
    },
    {
      title: "Design pattern project (COS214 project)",
      distance: "Half Marathon",
      description: "Collaborative project about different software models",
      tech: ["C++", "Groupwork", "Tailwind CSS"],
      github: "#",
      demo: "#"
    },
    {
      title: "Pokemon API fun project (personal Project)",
      distance: "5K Challenge",
      description: "Testing a connection to a pokemon api (this was one of my first times using an API)",
      tech: ["React", "Styled Components", "Contentful"],
      github: "#",
      demo: "#"
    },
    {
      title: "Standared HTML and CSS project (IMY110 project)",
      distance: "3K Sprint",
      description: "My first time coding a website, built in HTML CSS and a bit of JAvascript",
      tech: ["JavaScript", "HTML", "CSS"],
      github: "#",
      demo: "#"
    },
    {
      title: "Task Manager",
      distance: "10K Run",
      description: "Full-stack productivity app with user authentication",
      tech: ["Vue.js", "Firebase", "Vuetify"],
      github: "#",
      demo: "#"
    },
    {
      title: "Game Engine",
      distance: "Ultra Marathon",
      description: "Custom 2D game engine built from scratch",
      tech: ["C++", "OpenGL", "SDL2"],
      github: "#",
      demo: "#"
    },
    {
      title: "Mobile App",
      distance: "Half Marathon",
      description: "Cross-platform mobile application for fitness tracking",
      tech: ["React Native", "Redux", "SQLite"],
      github: "#",
      demo: "#"
    }
  ];

  return (
    <div className="projects-page">
      <nav className="projects-nav">
        <div className="projects-nav-content">
          <div className="projects-nav-left">
            <h2 className="projects-nav-title">Projects</h2>
          </div>
          <div className="projects-nav-center">
            <h1 className="projects-page-title">The Race Log</h1>
          </div>
          <div className="projects-nav-links">
            <button onClick={() => setCurrentPage('splash')}>Home</button>
            <button onClick={() => setCurrentPage('about')}>About</button>
          </div>
        </div>
      </nav>

      <div className="projects-track">


        <div className="project-icons">
          {projects.map((project, idx) => {
            let leftPos, topPos;
            
            // ========== MARKER POSITIONING SECTION ==========
            // Edit the values below to customize marker positions
            // leftPos: horizontal position (0% = left edge, 100% = right edge)
            // topPos: vertical position (0% = top edge, 100% = bottom edge)
            // Negative values place markers outside the visible area
            
            if (idx === 0) {
              // Project 1: IMY220 project - Far left marker
              leftPos = '-20%';
              topPos = '70%';
            } else if (idx === 1) {
              // Project 2: COS216 Project - Left-middle marker
              leftPos = '35%';
              topPos = '40%';
            } else if (idx === 2) {
              // Project 3: COS214 project - Right-middle marker
              leftPos = '63%';
              topPos = '45%';
            } else if (idx === 3) {
              // Project 4: Portfolio Generator - Far right marker
              leftPos = '100%';
              topPos = '-30%';
            } else if (idx === 4) {
              // Project 5: Weather App - Top-left marker
              leftPos = '20%';
              topPos = '0%';
            } else if (idx === 5) {
              // Project 6: Task Manager - Bottom-center marker
              leftPos = '25%';
              topPos = '110%';
            } else if (idx === 6) {
              // Project 7: Game Engine - Top-right marker
              leftPos = '56%';
              topPos = '-20%';
            } else if (idx === 7) {
              // Project 8: Mobile App - Center-right marker
              leftPos = '90%';
              topPos = '55%';
            } else {
              // Default positioning for any additional projects
              leftPos = `${20 + (idx * 10)}%`;
              topPos = `${30 + (idx % 3 * 20)}%`;
            }
            // ===============================================
            
            return (
              <div 
                key={idx} 
                className="project-icon-marker"
                style={{
                  left: leftPos,
                  top: topPos,
                  animationDelay: `${0.5 + idx * 0.1}s`
                }}
                onClick={() => setSelectedProject(project)}
              >
                <Code size={24} />
                <span className="project-icon-label">{project.title}</span>
              </div>
            );
          })}
        </div>
      </div>

      {selectedProject && (
        <div className="project-modal" onClick={() => setSelectedProject(null)}>
          <div className="project-modal-content" onClick={(e) => e.stopPropagation()}>
            <button 
              className="project-modal-close"
              onClick={() => setSelectedProject(null)}
            >
              <X size={24} />
            </button>
            
            <div className="project-card-header">
              <div className="project-card-title">
                <h3>{selectedProject.title}</h3>
                <span className="project-distance">
                  {selectedProject.distance}
                </span>
              </div>
              <Code className="project-icon" />
            </div>
            
            <p className="project-description">{selectedProject.description}</p>
            
            <div className="project-tech">
              {selectedProject.tech.map((tech, i) => (
                <span key={i} className="project-tech-tag">
                  {tech}
                </span>
              ))}
            </div>

            <div className="project-links">
              <a href={selectedProject.github} className="project-link">
                <Github size={16} />
                Code
              </a>
              <a href={selectedProject.demo} className="project-link">
                <ExternalLink size={16} />
                Live Demo
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectsPage;